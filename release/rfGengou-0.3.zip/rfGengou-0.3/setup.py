from distutils.core import setup;
setup(
	name="rfGengou",
	version="0.3",
	py_modules=["rfGengou"],
	scripts=['rfgengou', 'rfgengou.bat', 'rfGengouCmd.py'],
)
